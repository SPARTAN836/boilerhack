function [] = LevelCurve_graph(x_1,y_1, x_f, y_f) 
x_1 = 2;
y_1 = 0;
x_f = -2;
y_f = 0;

% Define the function z = 4 - x^2 - y^2
zFunc = @(x, y) 4 - x.^2 - y.^2;

% Create a meshgrid for x and y values (e.g., ranging from -2 to 2 for visualization)
x = linspace(x_1-1, x_f+1, 100);  % x values from -2 to 2
y = linspace(y_1-1, y_f+1, 100);  % y values from -2 to 2
[X, Y] = meshgrid(x, y);   % Create meshgrid

% Evaluate the function for each point in the grid
Z = zFunc(X, Y);

% Plot the level curve using contour plot
figure;
contour(X, Y, Z, 20);  % 20 contour levels
title('Level Curve of z = 4 - x^2 - y^2');
xlabel('x');
ylabel('y');
colorbar;  % Show a color bar to indicate values of z
axis equal;  % Keep aspect ratio equal
