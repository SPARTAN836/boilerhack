T_eng = input("Enter engine's torque rating: ");
mass = input("Input weight of the car: ");
xStart = input("Enter x-coordinate at start: ");
yStart = input("Enter y-coordinate at start: ");
xEnd = input("Enter x-coordinate at end: ");
yEnd = input("Enter y-coordinate at end: "); 
fric = input("Enter friction constant (kinetic): ");
radius = 0.5842;

zCoor = zeros(5, 5);
for xi = -xStart:xStart
    for yi = -yStart:yStart
        zCoor(xi + xStart + 1, yi + yStart + 1) = 4 - (xi.^2 + yi.^2); % z function
    end
end

x = [];
y = [];
z = [];

i = 2;

initialX = 0;
initialY = 0;
x(1) = levelCurve(T_eng, mass, radius, fric, zCoor, initialX, initialY);
y(1) = levelCurve(T_eng, mass, radius, fric, zCoor, initialX, initialY);
z(1) = levelCurve(T_eng, mass, radius, fric, zCoor, initialX, initialY);

while xStart ~= xEnd || yStart ~= yEnd
    x(i) = levelCurve(T_eng, mass, radius, fric, zCoor, x(i-1), y(i-1));
    y(i) = levelCurve(T_eng, mass, radius, fric, zCoor, x(i-1), y(i-1));
    z(i) = levelCurve(T_eng, mass, radius, fric, zCoor, x(i-1), y(i-1));
    i = i + 1;
    
    % Update current position
    x(i) = xStart;
    y(i)=yStart;
end

disp('x-coordinates:');
disp(x);
disp('y-coordinates:');
disp(y);
disp('z-coordinates:');
disp(z);
