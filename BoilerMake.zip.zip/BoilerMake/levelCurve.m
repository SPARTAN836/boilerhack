function [x, y, z] = levelCurve(T_eng, mass, radius, fric, zCoor, xi, yi)
    % Initialize initial z value at (xi, yi)
    z0 = 4 -(xi^2 + yi^2);
    
    % Define possible adjacent positions
    possibleX = [xi - 1, xi - 1, xi, xi + 1, xi + 1];
    possibleY = [yi, yi + 1, yi + 1, yi, yi + 1];
    
    % Check for out-of-bounds indices
    condition = (possibleX <= 0 | possibleX > size(zCoor, 1)) | (possibleY <= 0 | possibleY > size(zCoor, 2));
    possibleX(condition) = [];
    possibleY(condition) = [];
    
    % Initialize possibleZ
    possibleZ = zeros(size(possibleX));
    
    % Populate possibleZ with valid values from zCoor
    for j = 1:length(possibleY)
        if possibleX(j) > 0 && possibleX(j) <= size(zCoor, 1) && possibleY(j) > 0 && possibleY(j) <= size(zCoor, 2)
            possibleZ(j) = zCoor(possibleX(j), possibleY(j));
        end
    end
    
    % Calculate rho, cos_phi, and sin_phi
    rho = sqrt((possibleX - xi).^2 + (possibleY - yi).^2 + (possibleZ - z0).^2);
    cos_phi = (possibleZ - z0) ./ rho;
    sin_phi = sqrt((possibleX - xi).^2 + (possibleY - yi).^2) ./ rho;
    
   
    % Initialize variables for maximum Z and travel index
    maxZ = -Inf;
    travel_index = -1;
    
    % Loop through possibleZ to find the best candidate
    for k = 1:length(possibleZ)
        if T_eng > mass * 9.8 * radius * (fric * cos_phi(k) + sin_phi(k)) / 4.1 && possibleZ(k) > maxZ
            
            maxZ = possibleZ(k);
            travel_index = k;
        end
    end
    
    % Ensure travel_index is valid before accessing possibleX, possibleY, possibleZ
    if travel_index == -1
        fprintf('No valid travel index found based on the criteria.');
    
    else
    
        % Return the best coordinates and z value
        x = possibleX(travel_index);
        y = possibleY(travel_index);
        z = possibleZ(travel_index);
    end
end